//
//  SecondViewController.swift
//  TeamProject
//
//  Created by sebastian manco on 11/9/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import UIKit
import CoreData

class CreateViewController: UIViewController {
    
    @IBOutlet var meetingtitle: UITextField!
    @IBOutlet var location: UITextField!
    @IBOutlet var date: UITextField!
    @IBOutlet var duration: UITextField!
    @IBOutlet var agenda: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    var meet : Meeting!
    @IBAction func Create(_ sender: Any) {
        let appDelegate = UIApplication.shared.delegate as! AppDelegate
        
        let context = appDelegate.persistentContainer.viewContext
        let newMeeting = NSEntityDescription.insertNewObject(forEntityName: "Meeting", into: context)
      
                // If appropriate, configure the new managed object.
       newMeeting.setValue(agenda.text, forKey: "agenda")
        newMeeting.setValue(duration.text, forKey: "duration")
        newMeeting.setValue(location.text, forKey: "location")
        newMeeting.setValue(date.text, forKey: "time")
       newMeeting.setValue(meetingtitle.text, forKey: "title")
        
        
       
        
        // Save the context.
        do {
            try context.save()
        } catch {
           
            let nserror = error as NSError
            fatalError("Unresolved error \(nserror), \(nserror.userInfo)")
        }
        
    }
    
    
    // dismiss the keyboard when return is pressed
    func textFieldShouldReturn(_ textField: UITextField) -> Bool {
        textField.resignFirstResponder()
        return true
    }
    
    // dismiss the keyboard when tap away
    @IBAction func BackgroundTapped(_ sender: UITapGestureRecognizer) {
        view.endEditing(true)
        view.endEditing(true)
    }
}

