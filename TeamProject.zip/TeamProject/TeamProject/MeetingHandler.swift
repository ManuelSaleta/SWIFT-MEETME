//
//  MeetingHandler.swift
//  TeamProject
//
//  Created by manuel saleta on 11/15/17.
//  Copyright © 2017 FIU. All rights reserved.
//


/*
 Using the Factory Design Pattern
 This class is a way to handle Meeting objects and their interaction
 
 */
import Foundation
public class MeetingHandler
{
    //MeetingHandler should be a singleton
    static let shared = MeetingHandler()
    
    //Contains list of meetings
    private var meetingsList:[Meeting] = []

   
}
