//
//  FirstViewController.swift
//  TeamProject
//
//  Created by sebastian manco on 11/9/17.
//  Copyright © 2017 FIU. All rights reserved.
//

import UIKit
import Foundation
import CoreData

class HomeViewController: UIViewController, UITableViewDataSource , UITableViewDelegate, NSFetchedResultsControllerDelegate{
    
    
    @IBOutlet weak var pastMeetingsTableView: UITableView!
    
    
    @IBOutlet weak var tableView: UITableView!
    
    //var fetchedResultsController: NSFetchResultsController!
    
    var pastMeetings: [String] = ["One1","Two2","Three3","Four4","Five5","Six6","Seven7","Eight8"]
    
var itemStore: [String] = ["One","Two","Three","Four","Five","Six","Seven","Eight"]
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }
    

    
    //upcommingMeetings Table
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        print(#function)
    var count:Int?
    if tableView == self.tableView{

        count=itemStore.count
    }
    if tableView == self.pastMeetingsTableView{
        count = pastMeetings.count
    }
        return count!
    }
    
    
    
   func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        var cell:UITableViewCell?
        
        if tableView == self.tableView
        {
            
            cell = tableView.dequeueReusableCell(withIdentifier: "UpcomingCell", for: indexPath)
            let item = itemStore[indexPath.row]
            cell?.textLabel?.text = item
        return cell!
        }
        
        if tableView == pastMeetingsTableView
        {
            cell = tableView.dequeueReusableCell(withIdentifier: "UITableViewCell", for: indexPath)
            let pastmeeting = pastMeetings[indexPath.row]
            cell?.textLabel?.text = pastmeeting
        }
        return cell!

    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}

