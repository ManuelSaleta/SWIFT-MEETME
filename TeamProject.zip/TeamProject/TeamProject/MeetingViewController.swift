//
//  MeetingView.swift
//  TeamProject
//
//  Created by sebastian manco on 11/12/17.
//  Copyright © 2017 FIU. All rights reserved.
//
import UIKit
import UserNotifications
import AVFoundation


class MeetingViewController: UIViewController {
    
    @IBOutlet weak var askButton: UIButton!
    
    @IBOutlet weak var viewQuestionsButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.askButton.layer.cornerRadius = 10
        self.viewQuestionsButton.layer.cornerRadius = 10
        
        UIApplication.shared.applicationIconBadgeNumber = 0 // Clears badge when opening apps
        
        // allows sound to play when when apps in background
        do {
            try AVAudioSession.sharedInstance().setCategory(AVAudioSessionCategoryPlayback)
            print("AVAudioSession Category Playback OK")
            do {
                try AVAudioSession.sharedInstance().setActive(true)
                print("AVAudioSession is Active")
            } catch let error as NSError {
                print(error.localizedDescription)
            }
        } catch let error as NSError {
            print(error.localizedDescription)
        }
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    var time = 10               // amount of time the timer will count in second
    var timer = Timer()         //calls timer class
    var player: AVAudioPlayer?  // calls the audio player
    var timerrun = false        // checks if the timer is running
    var backgroundTask: UIBackgroundTaskIdentifier = UIBackgroundTaskInvalid // allows app to run in background
    
    @IBOutlet var TimerLabel: UILabel!
    @IBAction func StartStopButton(_ sender: UIButton) {
        if self.timerrun == false {
            runTimer()
            registerBackgroundTask()
            timerrun = true
        }
        else if self.timerrun == true
        {
            timer.invalidate()
            endBackgroundTask()
            UIApplication.shared.applicationIconBadgeNumber = 0
            timerrun = false
        }
    }
    
    func runTimer(){
        timer = Timer.scheduledTimer(timeInterval: 1, target: self,   selector: (#selector(updateTimer)), userInfo: nil, repeats: true)
    }
    
    @objc func updateTimer(){
        if time < 1 && time > -5
        {
            playSound()
            if time == 0
            {
                notification()
            }
        }
        time -= 1     //This will decrement(count down)the seconds.
        TimerLabel.text = timeString(time: TimeInterval(time))
        
    }
    
    func timeString(time:TimeInterval) -> String {
        let hours = Int(time) / 3600
        let minutes = Int(time) / 60 % 60
        let seconds = Int(time) % 60
        
        return String(format:"%02i:%02i:%02i", hours, minutes, seconds)
    }
    
    func playSound(){
        
        let sound = Bundle.main.url(forResource: "alarm", withExtension: "mp3")
        do {
            player = try AVAudioPlayer(contentsOf: sound!)
            guard let player = player else { return }
            player.prepareToPlay()
            player.play()
            
            
        } catch let error {
            print(error.localizedDescription)
        }
    }
    
    func notification(){
        
        let timerNotification = UNMutableNotificationContent()
        timerNotification.title = "TIMEsUP!"
        timerNotification.subtitle = "Meeting is over"
        timerNotification.body = "Please Wrap-Up this meeting"
        timerNotification.badge  = 1 // display the badge
        
        let trigger = UNTimeIntervalNotificationTrigger(timeInterval: 5, repeats: false)
        
        let request = UNNotificationRequest(identifier: "timerDone", content: timerNotification, trigger: trigger)
        
        UNUserNotificationCenter.current().add(request, withCompletionHandler: nil)
        
        
        let alert = UIAlertController (title: "TIMES UP!!!", message: "Please Wrap-up this meeting", preferredStyle: UIAlertControllerStyle.alert)
        
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: { (action) in alert.dismiss(animated: true, completion: nil)
            
        }))
        
        self.present(alert, animated: true, completion: nil)
        
    }
    
    func registerBackgroundTask() {
        backgroundTask = UIApplication.shared.beginBackgroundTask { [weak self] in
            self?.endBackgroundTask()
        }
        assert(backgroundTask != UIBackgroundTaskInvalid)
    }
    
    func endBackgroundTask() {
        print("Background task ended.")
        UIApplication.shared.endBackgroundTask(backgroundTask)
        backgroundTask = UIBackgroundTaskInvalid
    }
    
    
    
}
