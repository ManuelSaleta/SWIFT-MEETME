//
//  MeetingView.swift
//  TeamProject
//
//  Created by sebastian manco on 11/12/17.
//  Copyright © 2017 FIU. All rights reserved.
//
import UIKit

class MeetingViewController: UIViewController {
    
    @IBOutlet weak var askButton: UIButton!
    
    @IBOutlet weak var viewQuestionsButton: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.askButton.layer.cornerRadius = 10
        self.viewQuestionsButton.layer.cornerRadius = 10
        
        // Do any additional setup after loading the view, typically from a nib.
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
}
