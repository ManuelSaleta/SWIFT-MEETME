//
//  Meeting.swift
//  TeamProject
//
//  Created by manuel saleta on 11/15/17.
//  Copyright © 2017 FIU. All rights reserved.
//

/*
 This class is in charge of creating a meeting Object
 Meetings should have
 AGENDA
 TITLE
 LOCATION
 DATE
 DURATION
 */
import Foundation

public class Meeting
{
    private var agenda: String = ""
    private var title: String = ""
    private var location: String = ""
    private var date: Date
    private var duration: Double
    
    init (agenda: String , title: String, location: String, date: Date, duration: Double)
    {
        self.agenda = agenda
        self.title = title
        self.location = location
        self.date = date
        self.duration = duration
    }
    
    //setters
    public func SetAgenda(agenda:String )-> Void
    {
        self.agenda = agenda
    }
    
    public func SetTitle(title:String )-> Void
    {
        self.title = title
    }
    
    public func SetLocation(location:String )-> Void
    {
        self.location = location
    }
    
    public func SetDate(date:Date )-> Void
    {
        self.date = date
    }
    
    public func SetDuration(duration:Double )-> Void
    {
        self.duration = duration
    }
    
    
    public func SetAgenda()-> String
    {
        return agenda
    }
    
    public func GetTitle(title:String )-> String
    {
        return title
    }
    
    public func GetLocation()-> String
    {
        return location
    }
    
    public func GetDate()-> Date
    {
        return date
    }
    
    public func GetDuration()-> Double
    {
        return duration
    }
}


